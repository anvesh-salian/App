import React, { useState } from 'react';
import MoodSelector from '@/components/MoodSelector';
import MoodCalendar from '@/components/MoodCalendar';
import Stats from '@/components/Stats';
import { format } from 'date-fns';

const Index = () => {
  const [moodData, setMoodData] = useState<Record<string, string>>({
    [format(new Date(), 'yyyy-MM-dd')]: 'happy',
  });
  const [selectedMood, setSelectedMood] = useState<string | null>(null);

  const handleMoodSelect = (mood: string) => {
    setSelectedMood(mood);
    const today = format(new Date(), 'yyyy-MM-dd');
    setMoodData(prev => ({
      ...prev,
      [today]: mood
    }));
  };

  return (
    <div style={{ backgroundColor: '#cceeff', minHeight: '100vh', padding: '1rem' }}>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-serif text-blue-700">
            Daily Emotions Tracker
          </h1>
          <p className="text-base font-sans text-gray-500">
            How was life today, Shreyu?
          </p>

        </div>

        <div className="p-6 bg-card rounded-lg shadow-sm border">
          <MoodSelector onMoodSelect={handleMoodSelect} selectedMood={selectedMood} />
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Your Mood Calendar</h2>
            <MoodCalendar moodData={moodData} />
          </div>
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Your Mood Stats</h2>
            <Stats moodData={moodData} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
