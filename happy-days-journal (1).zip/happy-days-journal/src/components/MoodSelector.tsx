
import React from 'react';
import { Button } from "@/components/ui/button";
import { SmilePlus, Smile, Meh, Frown, Angry } from "lucide-react";
import { Moon, MoonStar } from "lucide-react";
import { Ghost, Flame, PartyPopper } from 'lucide-react';
import { cn } from "@/lib/utils";

interface MoodSelectorProps {
  onMoodSelect: (mood: string) => void;
  selectedMood: string | null;
}

const moods = [
  { name: 'okayish', icon: Meh, color: 'bg-gradient-to-br from-cyan-100 to-cyan-300', textColor: 'text-yellow-800' },
  { name: 'sleepy', icon: Moon , color: 'bg-gradient-to-br from-purple-100 to-purple-300', textColor: 'text-yellow-800' },
  { name: 'happy', icon: Smile, color: 'bg-gradient-to-br from-yellow-100 to-yellow-300', textColor: 'text-yellow-800'},
  { name: 'calm', icon: SmilePlus, color: 'bg-gradient-to-br from-green-100 to-green-300', textColor: 'text-green-800' },
  { name: 'sad', icon: Frown, color: 'bg-gradient-to-br from-blue-100 to-blue-300', textColor: 'text-blue-800' },
  { name: 'angry', icon: Angry, color: 'bg-gradient-to-br from-red-100 to-red-300', textColor: 'text-red-800' },
];

const MoodSelector = ({ onMoodSelect, selectedMood }: MoodSelectorProps) => {
  return (
    <div className="flex flex-wrap gap-4 justify-center">
      {moods.map((mood) => {
        const Icon = mood.icon;
        return (
          <Button
            key={mood.name}
            variant="outline"
            size="lg"
            className={cn(
              "h-20 w-20 rounded-xl transition-all duration-200 hover:scale-105 shadow-md",
              selectedMood === mood.name 
                ? `${mood.color} ${mood.textColor} border-transparent` 
                : `hover:${mood.color} hover:${mood.textColor} border-gray-300`
            )}
            onClick={() => onMoodSelect(mood.name)}
          >
            <Icon className="h-10 w-10" />
          </Button>
        );
      })}
    </div>
  );
};

export default MoodSelector;

