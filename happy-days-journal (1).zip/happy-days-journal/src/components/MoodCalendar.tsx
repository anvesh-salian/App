
import React from 'react';
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";

interface MoodCalendarProps {
  moodData: Record<string, string>;
  className?: string;
}

const moodColors: Record<string, string> = {
  happy: "bg-gradient-to-br from-yellow-200 to-yellow-400 text-yellow-900",
  calm: "bg-gradient-to-br from-green-200 to-green-400 text-green-900",
  sad: "bg-gradient-to-br from-blue-200 to-blue-400 text-blue-900",
  angry: "bg-gradient-to-br from-red-200 to-red-400 text-red-900",
};

const MoodCalendar = ({ moodData, className }: MoodCalendarProps) => {
  const modifiers = {
    mood: (date: Date) => {
      const dateStr = date.toISOString().split('T')[0];
      return dateStr in moodData;
    },
  };

  const modifiersStyles = {
    mood: {
      fontWeight: "bold",
    },
  };

  return (
    <Calendar
      mode="single"
      modifiers={modifiers}
      modifiersStyles={modifiersStyles}
      className={cn("rounded-md border w-full p-3 shadow-sm", className)}
      selected={new Date()}
      onSelect={() => {}}
      components={{
        DayContent: ({ date }) => {
          const dateStr = date.toISOString().split('T')[0];
          const mood = moodData[dateStr];
          return (
            <div className={cn(
              "h-8 w-8 p-0 font-normal aria-selected:opacity-100",
              mood ? moodColors[mood] : "hover:bg-muted",
              "rounded-full flex items-center justify-center transition-colors"
            )}>
              {date.getDate()}
            </div>
          );
        },
      }}
    />
  );
};

export default MoodCalendar;

