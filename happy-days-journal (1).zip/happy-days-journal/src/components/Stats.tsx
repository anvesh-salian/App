
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface StatsProps {
  moodData: Record<string, string>;
}

const Stats = ({ moodData }: StatsProps) => {
  const moodCounts = Object.values(moodData).reduce((acc, mood) => {
    acc[mood] = (acc[mood] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const totalDays = Object.keys(moodData).length;

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {Object.entries(moodCounts).map(([mood, count]) => (
        <Card key={mood}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium capitalize">
              {mood} days
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{count}</div>
            <p className="text-xs text-muted-foreground">
              {((count / totalDays) * 100).toFixed(1)}% of the time
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default Stats;
