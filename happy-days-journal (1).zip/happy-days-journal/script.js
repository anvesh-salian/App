function greet() {
  alert("You just clicked Anvesh’s first app 😎🔥");
}
